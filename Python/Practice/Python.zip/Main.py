Dir = "/sdcard/Project§/Python"
from random import random as r
from New import Screen
from time import sleep
import sys
len = 18
FRAME = 0.1
s = Screen(len,len)
Symb = "∆"
Colr = 'Yellow'
#sys.stdin.read(1)
maxH = s.rows 
maxW = s.cols
i,j,H,V= 0,0,0,0

#while H == 0:
#	j += 1
#	H = s.Hr(j,"@","red")
#	s.src()
#	sleep(FRAME)
#	s.clear()

#while V == 0:
#	i += 1
#	V = s.Vr(i,"#","Gray")
#	s.src()
#	sleep(FRAME)
#	s.clear()
#no = 0
#while H == 1 and V == 1 and no <= 20:
#	Point = (int(r()*maxH) + 1,int(r()*maxW) + 1)
#	s.setData(Point,Symb)
#	s.setColr(Point,Colr)
#	s.src()
#	sleep(FRAME/10)
#	if not no == 20:
#		s.clear()
#	no += 1
#	
#H = 0
#while H == 0:
#	j -= 1
#	H = s.Hr(j," ","red")
#	s.src()
#	sleep(FRAME)
#	s.clear()
#V = 0
#while V == 0:
#	i -= 1
#	V = s.Vr(i,"•","Blue")
#	s.src()
#	sleep(FRAME)
#	if not V == 1:
#		s.clear()
#s.src()
#sleep(1)
AW = '#'
Frm = 0.05
W =[(1,1),(18,6),(9,9),(18,12),(1,18)]
A = [(17,1),(3,9),(17,18)]
for a in W :
	if(a == W[0]):
		b = a
		continue
	s.line(b,a,AW,'Cyan',Frame = Frm,src = True)
	b = a
for a in A :
	if(a == A[0]):
		b = a
		continue
	s.line(b,a,AW,'Cyan',Frame = Frm,src = True)
	b = a