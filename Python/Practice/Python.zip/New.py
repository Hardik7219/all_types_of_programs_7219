# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                                                     #
#                                                                                                     #
#                    Just A Simple Comment. Distinguishing Between Things.                            #
#                                                                                                     #
#                                                                                                     #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #


import os
import sys
#sys.path.append(".")
import Data
from time import sleep
class Screen:
    style = 1
    saved_Data = "./Data.py"
    file = "./new"
    defCol = 'default'
    Default = '\033[{};37m'.format(style)
    Gray = '\033[{};30m'.format(style)
    Red = '\033[{};31m'.format(style)
    Green = '\033[{};32m'.format(style)
    Yellow = '\033[{};33m'.format(style)
    Blue = '\033[{};34m'.format(style)
    Pink = '\033[{};35m'.format(style)
    Cyan = '\033[{};36m'.format(style)
    
    Color = { 'default' : Default,
    'gray' : Gray,
    'red' : Red,
    'green' : Green,
    'yellow' : Yellow,
    'blue' : Blue,
    'pink' : Pink,
    'cyan' : Cyan
    }

    srcData = {(0,0) : ' '}
    srcColr = {(0,0) : Green}
    Blank = ' '
    Symb = '#'
    
    
    def __init__(self,rows : int,cols : int):
    	self.rows = rows
    	self.cols = cols
    	self.Height = rows + 2
    	self.Width = cols + 2
    	for i in range(0,rows + 2):
    		for j in range(0,cols + 2):
    			if i == 0 or j == 0 or i == rows +1 or j == cols + 1 :
    				self.srcData[(i,j)] = '#' 
    				self.srcColr[(i,j)] = self.Green
    			else:
    				self.srcData[(i,j)] = self.Blank
    				self.srcColr[(i,j)] = self.Default
    
    
    def src(self):
    	#f = open(file,"w")
    	for i in range(0,self.rows + 2):
    		print("    ",end = "")
    		#sys.stdout.flush()
    		for j in range(0,self.cols + 2):
    			print(self.srcColr[(i,j)] + self.srcData[(i,j)] + self.Default,end = ' ')
    			#sys.stdout.flush()
    		print("")
    		#sys.stdout.flush()
    	#f.close()
    
    
    def setData(self,i : tuple,content):
    	self.srcData[i] = content + ''
    
    
    def setColr(self,i : tuple,content : str):
    	try:
    		content = content.lower()
    	except:
    		pass
    	self.srcColr[i] = self.Color[content]
    
    
    def clear(self):
    	os.system('cls' if os.name == "nt" else "clear")
    	
    
    def fill(self,a : tuple, b : tuple,color : str):
    	for i in range(a[0],b[0] + 1):
    		for j in range(a[1],b[1] + 1):
    			self.srcColr[(i,j)] = self.Color[color.lower()]
    	
    	
    def save(self):
    	with open(self.saved_Data,"w") as f:
    		print("data = ",self.srcData,"\n" + "colr = ",self.srcColr,file = f)
    
    
    def load(self):
    	self.srcData = Data.data
    	self.srcColr = Data.colr
    	
    def Hr(self,i : int,Sym,Colr):
    	if not (i>self.rows or i<=0):
    		Colr = Colr.lower()
    		for j in range(1,self.cols + 1):
    			self.srcData[(i,j)] = Sym
    			self.srcColr[(i,j)] = self.Color[Colr]
    		return 0
    	else:
    		return 1
    
    
    def Vr(self,j : int,Sym,Colr):
    	if j > self.cols or j <= 0:
    		return 1
    		exit(0)
    	Colr = Colr.lower()
    	for i in range(1,self.rows + 1):
    		self.srcData[(i,j)] = Sym
    		self.srcColr[(i,j)] = self.Color[Colr]
    	return 0
    	
    
    def line(self, start: tuple, end: tuple, sym: str = '#', colr: str = 'green',Frame : float = 0.5,src : bool = False):
        x0, y0 = start[1], start[0]
        x1, y1 = end[1], end[0]
        dx = abs(x1 - x0)
        dy = -abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx + dy

        colr = colr.lower()
        while True:
            self.srcData[(y0, x0)] = sym
            self.srcColr[(y0, x0)] = self.Color[colr]
            if(src):
            	self.clear()
            	self.src()
            	sleep(Frame)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy
                x0 += sx
            if e2 <= dx:
                err += dx
                y0 += sy